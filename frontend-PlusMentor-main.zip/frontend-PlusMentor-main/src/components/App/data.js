let interactionArray = [
  {
    topic: `Switch Statements - What does case mean?`,
    discussion: `The switch statement is used to perform different actions based on different conditions`,
    team_id: 2,
  },
  {
    topic: `Life in the Tech Industry - what advice would you give for someone starting out? `,
    discussion: `Research the job market, networking, building a portfolio`,
    team_id: 2,
  },
  {
    topic: `How hard is it to learn different programming languages `,
    discussion: `Learning the structure of basic programming languages is the hardest park, most jobs will give you time to research and once you have the structure is is easier to apply`,
    team_id: 2,
  },
];
